<?php
class Main_adminController
{
    public function detail()
    {
        $main_adminModel = new MainAdminModel();
        //$main_admin['abc'] = $main_adminModel->get_abc();

        //return $main_admin;
    }
}
