<?php
class MainAdminModel
{
    /*
    public function get_abc()
    {
        $main_admin['abc'] = '';

        return $main_admin;
    }
    */
}
