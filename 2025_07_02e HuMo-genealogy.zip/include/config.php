<?php

/**
 * General config variables. 
 */

$config = array(
    "dbh" => $dbh,
    "db_functions" => $db_functions,
    "tree_id" => $tree_id,
    "user" => $user,
    "humo_option" => $humo_option,
    "uri_path" => $uri_path
);
