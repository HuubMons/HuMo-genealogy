<?php
$name = 'DejaVuSansCondensed-BoldOblique';
$type = 'TTF';
$desc = array(
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 262212,
  'FontBBox' => '[-960 -385 1799 1121]',
  'ItalicAngle' => -11.0,
  'StemV' => 165.0,
  'MissingWidth' => 540.0,
);
$up = -63;
$ut = 44;
//$ttffile='include/tfpdf/font/unifont/DejaVuSansCondensed-BoldOblique.ttf';
$ttffile = __DIR__ . '/DejaVuSansCondensed-BoldOblique.ttf';
$originalsize = 611836;
$fontkey = 'dejavuBI';
