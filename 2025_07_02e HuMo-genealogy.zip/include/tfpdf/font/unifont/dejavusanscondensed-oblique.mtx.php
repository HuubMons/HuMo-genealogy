<?php
$name = 'DejaVuSansCondensed-Oblique';
$type = 'TTF';
$desc = array(
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 68,
  'FontBBox' => '[-914 -350 1493 1068]',
  'ItalicAngle' => -11.0,
  'StemV' => 87.0,
  'MissingWidth' => 540.0,
);
$up = -63;
$ut = 44;
//$ttffile='include/tfpdf/font/unifont/DejaVuSansCondensed-Oblique.ttf';
$ttffile = __DIR__ . '/DejaVuSansCondensed-Oblique.ttf';
$originalsize = 599292;
$fontkey = 'dejavuI';
