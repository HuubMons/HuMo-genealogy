<?php
$language["name"]="Fran&ccedil;ais";
$language["dir"]="ltr"; // "ltr" for left-to-right languages, "rtl" for right-to-left languages
?>
