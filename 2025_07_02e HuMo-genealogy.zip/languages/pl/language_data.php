<?php
$language["name"]="J&eogon;zyk polski";
$language["dir"]="ltr"; // "ltr" for left-to-right languages, "rtl" for right-to-left languages
?>
