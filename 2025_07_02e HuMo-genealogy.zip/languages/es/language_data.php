<?php
$language["name"]="Espa&ntilde;ol";
$language["dir"]="ltr"; // "ltr" for left-to-right languages, "rtl" for right-to-left languages
?>
