<?php
$language["name"]="עברית";
$language["dir"]="rtl"; // "ltr" for left-to-right languages, "rtl" for right-to-left languages
?>
