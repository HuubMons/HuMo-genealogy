<?php
$language["name"]="Portuguese";
$language["dir"]="ltr"; // "ltr" for left-to-right languages, "rtl" for right-to-left languages
?>
