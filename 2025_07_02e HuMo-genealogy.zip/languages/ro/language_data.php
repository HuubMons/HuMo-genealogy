<?php
$language["name"]="Română";
$language["dir"]="ltr"; // "ltr" for left-to-right languages, "rtl" for right-to-left languages
?>
