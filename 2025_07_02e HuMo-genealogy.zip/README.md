# HuMo-genealogy

>
> HuMo-genealogy is free and open-source genealogy software.
>
> You can download the current version [here](https://github.com/HuubMons/HuMo-genealogy/).
>

## Links

- [Website](https://humo-gen.com)
- [Demo website](https://humo-gen.com/humo-gen/)
- [Forum](https://humo-gen.com/genforum/)
- [Documentation](https://sourceforge.net/projects/humo-gen/files/HuMo-gen_Manual/)