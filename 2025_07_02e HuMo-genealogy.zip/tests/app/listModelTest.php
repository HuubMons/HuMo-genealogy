<?php

// Just a first test trying to use PHPUnit.

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class ListModelTest extends TestCase
{
    public function testGetIndexList(): void
    {
        $_POST["index_list"] = 'test_list';

        $ListModel = new ListModel;
        $result = $ListModel->getIndexList();

        $this->assertSame('test_list', $result);
    }
}
