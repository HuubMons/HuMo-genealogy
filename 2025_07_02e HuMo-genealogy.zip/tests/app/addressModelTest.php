<?php

// Just a first test trying to use PHPUnit.

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class AddressModelTest extends TestCase
{
    public function testGetAddressAuthorised(): void
    {
        $db_functions = 'db_functions';
        $user['group_addresses'] = 'j';

        $AddressModel = new AddressModel($db_functions);
        $authorised = $AddressModel->getAddressAuthorised($user);

        $this->assertSame('', $authorised);
    }
}
